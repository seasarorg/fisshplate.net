﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Seasar.S2Fisshplate.Test.Interceptors
{
    public class HogeDto
    {
            public string Name { get; set; }
            public int Num { get; set; }
            public DateTime Date { get; set; }

            public HogeDto() { }
    }
}
